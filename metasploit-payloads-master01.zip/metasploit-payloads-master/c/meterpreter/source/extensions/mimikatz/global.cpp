#include "global.h" 

std::wostringstream oss;
std::wostringstream *outputStream = &oss;