/*!
 * @file window.h
 * @brief Declarations for window management functionality
 */
#ifndef _METERPRETER_SOURCE_EXTENSION_EXTAPI_WINDOW_H
#define _METERPRETER_SOURCE_EXTENSION_EXTAPI_WINDOW_H

DWORD request_window_enum(Remote *remote, Packet *packet);

#endif
