#ifndef _METERPRETER_SOURCE_ELEVATOR_NAMEDPIPESERVICE_H
#define _METERPRETER_SOURCE_ELEVATOR_NAMEDPIPESERVICE_H

BOOL elevator_namedpipeservice( char * cpServiceName );

#endif
