/*!
 * @mainpage Meterpreter Project Documentation
 *
 * This is the auto-generated documentation for the
 * [Meterpreter](https://github.com/rapid7/meterpreter) project; the
 * native payload for Windows and Linux in [Metasploit](https://github.com/rapid7/metasploit-framework)
 *
 * This documentation comes straight from the source and is created with doxygen.
 *
 * The source has only just started being annotated by the developers, hence the
 * documentation found here is scant. Over time, more and more work will be put
 * into filling the holes so that the source becomes more understandable and
 * easier to contribute to.
 *
 * For more information on Metasploit and Meterpreter, contact the fine folks
 * at [Rapid7](http://www.rapid7.com/).
 */// Stub that contains the main page documentation for the project.
